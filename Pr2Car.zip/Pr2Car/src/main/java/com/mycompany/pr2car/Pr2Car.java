/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pr2car;

import java.util.Scanner;

/**
 *
 * @author М_З_А
 */
public class Pr2Car {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Практическая работа №2, вариант 1, Пашин А.М., РИБО-01-21");
        System.out.println("Введите марку машины: ");
        String nm = scan.next();
        System.out.println("Введите максимальную скорость: ");
        int ms = scan.nextInt();
        System.out.println("Введите пробег: ");
        double pr = scan.nextDouble();
        System.out.println("Введите дистанцию торможения: ");
        double sd = scan.nextDouble();
        Car car = new Car(ms,nm,pr,sd);
        System.out.println("Выберите цифру: 1 - Пассажирский транспорт, 2 - Грузовой транспорт");
        int a = scan.nextInt();
        if (a == 1){
            System.out.println("Введите стоимость: ");
            int prc = scan.nextInt();
            System.out.println("Введите пассажировместимость: ");
            String pc = scan.next();
            PassCar car1 = new PassCar(prc,pc,ms,nm,pr,sd);
            System.out.println(car1.toString());
        }
        else {
        System.out.println("Введите цвет: ");
            String col = scan.next();
            System.out.println("Введите высоту машины: ");
            double th = scan.nextDouble();
            Truck car2 = new Truck(col,th,ms,nm,pr,sd);
            System.out.println(car2.toString());
        }
    }
}
