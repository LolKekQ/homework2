/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pr2car;

/**
 *
 * @author М_З_А
 */
public class Car {
    private int maxSpeed;
    private String carBrand;
    private double carMileage;
    private double stoppingDistance;

    public Car(int maxSpeed, String carBrand, double carMileage, double stoppingDistance) {
        this.maxSpeed = maxSpeed;
        this.carBrand = carBrand;
        this.carMileage = carMileage;
        this.stoppingDistance = stoppingDistance;
    }

    public int getMaxSpeed() {
        return maxSpeed;
    }

    public void setMaxSpeed(int maxSpeed) {
        this.maxSpeed = maxSpeed;
    }

    public String getCarBrand() {
        return carBrand;
    }

    public void setCarBrand(String carBrand) {
        this.carBrand = carBrand;
    }

    public double getCarMileage() {
        return carMileage;
    }

    public void setCarMileage(double carMileage) {
        this.carMileage = carMileage;
    }

    public double getStoppingDistance() {
        return stoppingDistance;
    }

    public void setStoppingDistance(double stoppingDistance) {
        this.stoppingDistance = stoppingDistance;
    }
    
    public double timeToMaxSpeed(int distance){
        return distance*this.maxSpeed;
    }
    
    public void probeg(){
        System.out.println(this.carMileage);
    }
    
    public void name(){
    System.out.println(this.carBrand);
    }
}
