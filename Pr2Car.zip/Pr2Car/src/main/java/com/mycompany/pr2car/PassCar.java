/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pr2car;

/**
 *
 * @author М_З_А
 */
public class PassCar extends Car {
    private int price;
    private String passCapacity;

    public PassCar(int price, String passCapacity, int maxSpeed, String carBrand, double carMileage, double stoppingDistance) {
        super(maxSpeed, carBrand, carMileage, stoppingDistance);
        this.price = price;
        this.passCapacity = passCapacity;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getPassCapacity() {
        return passCapacity;
    }

    public void setPassCapacity(String passCapacity) {
        this.passCapacity = passCapacity;
    }

    public void passengersNumber(int passenersNumber){
        System.out.println(passenersNumber);
    }
    
    @Override
    public String toString(){
        return "PassCar{" + "Brand = " + getCarBrand() + ", max speed = " + getMaxSpeed() + ", car mileage = " + getCarMileage() + ", Stopping distance = " +getStoppingDistance() + ", price =" + getPrice() + ", pass capacity =" + getPassCapacity() + "}";
    }
}
